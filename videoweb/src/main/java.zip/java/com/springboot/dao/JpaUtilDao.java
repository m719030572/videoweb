package com.springboot.dao;

public class JpaUtilDao {

}
