package com.springboot.controller;

import org.springframework.stereotype.Controller;

@Controller
public class FluxVideoController {

}
