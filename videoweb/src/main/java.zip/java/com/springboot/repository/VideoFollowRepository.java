package com.springboot.repository;

public class VideoFollowRepository {

}
