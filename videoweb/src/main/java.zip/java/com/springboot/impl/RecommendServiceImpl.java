package com.springboot.impl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.springboot.domain.Recommend;
import com.springboot.domain.Video;
import com.springboot.repository.RecommendRepository;
import com.springboot.repository.VideoRepository;
import com.springboot.service.RecommendService;
import com.springboot.service.VideoService;
@Service
@Component
public class RecommendServiceImpl implements RecommendService
{
	@Autowired
	RecommendRepository rr;
	@Autowired
	VideoService vs;
	@Autowired
	VideoRepository vr;

	@Override
	public List<Video> getListAsUid(String uid) {
		List<Recommend> recommendlist=new ArrayList<>();
		recommendlist=rr.findByUid(uid);
		List<Video> videolist=new ArrayList<>();
		for(Recommend recommend:recommendlist)
		{
			videolist.add(vr.findById(recommend.getVid()).get());
		}
		return videolist;
	}
	@Override
	public List<Video> getDefaultRecommendList() {
		return getListAsUid("default");
	}
	@Override
	public void buildRecommendList() {
		try {
			FileReader fr = new FileReader("G:\\user.csv");
			 BufferedReader reader = new BufferedReader(fr);
			 List<Integer> user_list=new ArrayList<>();
				InputStream list = new FileInputStream("G:\\userlist.txt");
				Scanner scanner = new Scanner(list);
				while (scanner.hasNextInt()) {
					user_list.add(scanner.nextInt());	//读取用户列表
				}
				scanner.close();
				list.close();
				list = new FileInputStream("G:\\userout.csv");
				scanner = new Scanner(list);
				while(scanner.hasNextLine())
				{
					String str=scanner.nextLine();
					String strs[]=str.split(",");
					System.out.println(strs);
					for(String string:strs)
					{
						Double.parseDouble(string);
					}
				}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
	}
}
